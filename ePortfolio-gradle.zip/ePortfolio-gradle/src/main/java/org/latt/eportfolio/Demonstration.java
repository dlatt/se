package org.latt.eportfolio;

public class Demonstration {
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}
}